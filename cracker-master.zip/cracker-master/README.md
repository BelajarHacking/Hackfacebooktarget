# cracker

Crack Account Facebook Complete

# Install
pkg update

pkg upgrde

pkg install git ruby

pkg install python2

pkg install figlet

pip2 install --upgrade pip

gem install lolcat

git clone https://github.com/AlatToll/cracker.git

cd cracker

pip2 install -r requirements.txt

bash cracker.sh


<img src="Cracker.png">

<img src="Crack.png">
